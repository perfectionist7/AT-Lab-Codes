package com.example.midsem_practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var newval = intent.getStringExtra("key").toString();
        var newvalint = newval.toInt();
        var balance = 10000-newvalint;
        var done = findViewById<Button>(R.id.done)
        var textview2 = findViewById<TextView>(R.id.textView2)
        done.setOnClickListener {
            Toast.makeText(this@SecondActivity,"Remaining Balance $balance", Toast.LENGTH_SHORT).show();
            var baltext = balance;
            textview2.text = "Balance: $baltext";
        }



    }
}