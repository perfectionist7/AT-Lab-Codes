package com.example.midsem_practice

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_activity)
        var imgbutton = findViewById<ImageButton>(R.id.imgbut)
        var textview1 = findViewById<TextView>(R.id.textView)
        var textview2 = findViewById<TextView>(R.id.textView3)
        var potato = findViewById<EditText>(R.id.potato)
        var onion = findViewById<EditText>(R.id.onion)
        var button = findViewById<Button>(R.id.button)
        var listview = findViewById<ListView>(R.id.listView)
        var buy = findViewById<Button>(R.id.buy)
        textview1.visibility = View.INVISIBLE
        textview2.visibility = View.INVISIBLE
        potato.visibility = View.INVISIBLE
        onion.visibility = View.INVISIBLE
        button.visibility = View.INVISIBLE
        listview.visibility = View.INVISIBLE
        imgbutton.setOnClickListener {
            textview1.visibility = View.VISIBLE
            textview2.visibility = View.VISIBLE
            potato.visibility = View.VISIBLE
            onion.visibility = View.VISIBLE
            button.visibility = View.VISIBLE
            listview.visibility = View.VISIBLE
        }

        button.setOnClickListener {
            var onionquant = potato.text.toString();
            var potatoquant = potato.text.toString();
            val onionval = onionquant.toInt();
            val potatoval = potatoquant.toInt();
            var oniontot = onionval*10;
            var potatotot = potatoval*15;
            var items = arrayOf("Potato $potatotot","Onion $oniontot");
            var adapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,items);
            listview.adapter = adapter;

        }
        buy.setOnClickListener {
            var onionquant = potato.text.toString();
            var potatoquant = potato.text.toString();
            val onionval = onionquant.toInt();
            val potatoval = potatoquant.toInt();
            var oniontot = onionval*10;
            var potatotot = potatoval*15;
            var totval = oniontot + potatotot;

            val builder1 = AlertDialog.Builder(this)
            builder1.setMessage("Total value $totval")
            builder1.setCancelable(true)

            builder1.setPositiveButton(
                "Yes"
            ) { dialog, id ->             var intent = Intent(this@MainActivity,SecondActivity::class.java)
                intent.putExtra("key",totval.toString());
                startActivity(intent) }

            builder1.setNegativeButton(
                "No"
            ) { dialog, id -> dialog.cancel() }

            val alert11 = builder1.create()
            alert11.show()
        }
    }
}